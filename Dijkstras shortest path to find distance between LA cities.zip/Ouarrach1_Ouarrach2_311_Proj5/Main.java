// Ibrahim ouarrach
// done 12/09/2022


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
    static final int UNVISITED = 0;
    static final int VISITED = 1;
    static int[] D = new int[10];
    private static Graph G = new Graphl();
    private static Graph G1 = new Graphm();
    public static void main(String[] args) throws IOException
    {
        Scanner sc = new Scanner(System.in);
        boolean flag = true;
        List<String> city = List.of("Inglewood","Lynwood", "Compton", "Torrence", "PalosVerdes", "Carson","LongBeach", "Lakewood", "Norwalk", "Downey");
        while(flag)
        {
            menu();
            int choice = sc.nextInt();
            if(choice==1) {
                    System.out.println("LA Cities");
                    for (int i = 0; i < city.size(); i++) {
                        System.out.println(city.get(i));
                    }
                }
            if(choice ==2)
            {
                    boolean f1 =true;
                    String city1 =" ";
                    String city2 = " ";
                    while(f1)
                    {
                        System.out.println("Enter the first city");
                        city1 = sc.next();
                        if (!city.contains(city1))
                        {
                            System.out.println("City does not exist.");
                        }
                        else {
                            f1 =false;
                        }
                    }
                    while (!f1)
                    {
                        System.out.println("Enter the second city");
                        city2 = sc.next();
                        if (!city.contains(city2))
                        {
                            System.out.println("City does not exist");
                        }

                        else
                        {
                            f1 =true;
                        }
                    }

                    testGraph(city.indexOf(city1),G);
                    int distance = D[city.indexOf(city2)];
                    System.out.println("The distance between " + city1 + " and " + city2 + " is " + distance + " miles ");
            }
                if(choice ==3)
                {
                    boolean f2 =true;
                    String city3 ="";
                    String city4 = "";
                    while(f2)
                    {
                        System.out.println("Enter the first city");
                        city3 = sc.next();
                        if (!city.contains(city3))
                        {
                            System.out.println("City does not exist.");
                        }
                        else {
                            f2 =false;
                        }
                    }
                    while (!f2)
                    {
                        System.out.println("Enter the second city");
                        city4 = sc.next();
                        if (!city.contains(city4))
                        {
                            System.out.println("City does not exist");
                        }

                        else
                        {
                            f2 =true;
                        }
                    }

                    testGraph(city.indexOf(city3), G1);
                    int distance1 = D[city.indexOf(city4)];
                    System.out.println("The distance between " + city3 + " and " + city4 + " is " + distance1 + " miles ");
                }
                if(choice ==4)
                {
                    System.out.println("Thank You!");
                    flag  = false;
                }
                else
                    System.out.println("Please enter from above choices only");
            }
      }


        public static void menu()
    {
        System.out.println(" Welcome to LA City Map");
        System.out.println("1. Display the information of all cities.");
        System.out.println("2. Find the distance using adjacency list.");
        System.out.println("3. Find the distance using adjacency matrix.");
        System.out.println("4. Exit.");
        System.out.println("Enter your choice");

    }
    public static int getIndex(List v, String s)
    {
       return v.indexOf(s);
    }
    // Create a Graph
    static Graph createGraph(BufferedReader file, Graph G)
            throws IOException {
        String line = null;
        StringTokenizer token;
        boolean undirected = false;
        int i, v1, v2, weight;
        line = file.readLine();
        while (line.charAt(0) == '#')
            line = file.readLine();
        token = new StringTokenizer(line);
        int n = Integer.parseInt(token.nextToken());
        G.Init(n);
        for (i = 0; i < n; i++)
            G.setMark(i, UNVISITED);
        line = file.readLine();
        if (line.charAt(0) == 'U')
            undirected = true;
        else if (line.charAt(0) == 'D')
            undirected = false;
        else System.out.println("Bad graph type: " + line);
        // Read in edges
        while ((line = file.readLine()) != null) {
            token = new StringTokenizer(line);
            v1 = Integer.parseInt(token.nextToken());
            v2 = Integer.parseInt(token.nextToken());
            if (token.hasMoreTokens())
                weight = Integer.parseInt(token.nextToken());
            else // No weight given -- set at 1
                weight = 1;
            G.setEdge(v1, v2, weight);
            if (undirected) // Put in edge in other direction
                G.setEdge(v2, v1, weight);
        }
        return G;

    }
    // Dijkstra
    public static int minVertex(Graph G, int[] D) {
        int v = 0;  // Initialize v to any unvisited vertex;
        for (int i=0; i<G.n(); i++)
            if (G.getMark(i) == UNVISITED) { v = i; break; }
        for (int i=0; i<G.n(); i++)  // Now find smallest value
            if ((G.getMark(i) == UNVISITED) && (D[i] < D[v]))
                v = i;
        return v;
    }
    public static void Dijkstra(Graph G, int s, int[] D) {
        for (int i=0; i<G.n(); i++)    // Initialize
            D[i] = Integer.MAX_VALUE;
        D[s] = 0;
        for (int i=0; i<G.n(); i++) {  // Process the vertices
            int v = minVertex(G, D);     // Find next-closest vertex
            G.setMark(v, VISITED);
            if (D[v] == Integer.MAX_VALUE) return; // Unreachable
            for (int w = G.first(v); w < G.n(); w = G.next(v, w))
                if (D[w] > (D[v] + G.weight(v, w)))
                    D[w] = D[v] + G.weight(v, w);
        }
    }


    public static void testGraph(int source, Graph G) throws IOException {
        File file = new File("la_cities.gph") ;
        FileReader fr = new FileReader(file);
        BufferedReader f = new BufferedReader(fr);

        createGraph(f, G);
        Dijkstra(G, source, D);

    }
}
