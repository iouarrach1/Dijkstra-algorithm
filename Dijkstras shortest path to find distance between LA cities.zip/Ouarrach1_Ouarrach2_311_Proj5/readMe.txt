A) The program compiles well.
B) you need to have all the java files in the same folder, and then execute Main.java because it has the main method.
